class UCDataStorageBase:
    # abstract base class
    
    def __init__(self, *params, **args):
        raise ValueError("UCDataStorageBase is an abstract class and can not be instantiated")
        
    def createFolder(self, name, drop_existing=False):
        pass
        
    def getData(self, folder_name, data_key):
        # returns BLOB or None
        return None
        
    def putData(self, folder_name, data):
        # returns data key, text
        return None     
    
