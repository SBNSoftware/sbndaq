import psycopg2, sys, time, zlib
from psycopg2.extensions import adapt, register_adapter, AsIs
from datetime import datetime
#import cStringIO

#from trace import Tracer
from dbdig import DbDig
from UCon_backend import UCDataStorageBase
from py3 import to_str, to_bytes



class UCDPostgresDataStorage(UCDataStorageBase):

    def __init__(self, conn_or_connstr, default_namespace=None, detect_duplicates = True):
        self.Conn = self.ConnStr = None
        if isinstance(conn_or_connstr, str):
            self.ConnStr = conn_or_connstr
        else:
            self.Conn = conn_or_connstr
        self.DetectDuplicates = detect_duplicates
        self.DefaultNamespace = default_namespace

    def connect(self):
        if self.Conn == None:
            self.Conn = psycopg2.connect(self.ConnStr)
        return self.Conn
    
    def cursor(self):
        conn = self.connect()
        c = conn.cursor()
        if self.DefaultNamespace:
            c.execute(f"set schema '{self.DefaultNamespace}'")
        return c

    def tableName(self, folder_name):
        return "%s_data" % (folder_name,)

    def createFolder(self, name, owner, grants, drop_existing=False):
        c = self.cursor()
        table_name = self.tableName(name)
        exists = True
        try:    c.execute("select key from %s limit 1" % (table_name,))
        except:
            c.execute("rollback")
            exists = False
        if exists:
            if drop_existing:
                c.execute("drop table %s" % (table_name,))
            else:
                return

        if owner:
            c.execute("set role %s" % (owner,))

        words = table_name.split(".", 1)
        table_name_witout_namespace = table_name if len(words) == 1 else words[1]
        c.execute(f"""
            create table {table_name} (
                key     bigserial   primary key,
                hash    bigint,
                hash_type text default 'adler32',
                size    bigint,
                data    bytea);
            create index {table_name_witout_namespace}_hash_size_key on {table_name}(hash, size, key)""")
            
        read_roles = ','.join(grants.get('r',[]))
        if read_roles:
            c.execute(f"grant select on {table_name}, {table_name}_key_seq  to {read_roles}")
        write_roles = ','.join(grants.get('w',[]))
        if write_roles:
            c.execute(f"""
                    grant insert, delete, update on {table_name} to {write_roles};
                    grant all on {table_name}_key_seq to {write_roles}
            """)
        #c.execute("commit")
        

    def putData(self, folder_name, data):        
        data = to_bytes(data)
        a32 = zlib.adler32(data) & 0xFFFFFFFF
        l = len(data)
        #print("psql_backend.putData: data adler32, size:", a32, l)
        table_name = self.tableName(folder_name)
        key = None
        c = self.cursor()
        if self.DetectDuplicates:
            c.execute(f"""
                select key, data from {table_name}
                    where hash=%s and size=%s""", (a32, l))
            tup = c.fetchone()
            while tup is not None:
                k, d = tup
                #print("psql_backend: putData: data:", type(d), repr(d))
                if bytes(d) == data:
                    key = k
                    #print("putData: key found:", key)
                    break
                else:
                    #print("putData: data mismatch")
                    pass
                tup = c.fetchone()
        if not key:
                sql = f"""
                    insert into {table_name}(key, size, hash, data) values(default, %s, %s, %s)
                    returning key""" 
                c.execute(sql, (l, a32, psycopg2.Binary(data),))
                #c.execute(sql, (l, a32, data))
                key = c.fetchone()[0]
                c.execute("commit")
        return "%s" % (key,)
                   
    def getData(self, folder_name, key):
        table_name = self.tableName(folder_name)
        c = self.cursor()
        sql = """
            select data from %s
                where key = %%s""" % (table_name,)
        #print "sql=<%s> key=%s" % (sql, long(key))
        c.execute(sql, (key,))
        data = bytes(c.fetchone()[0])
        #print("psql_backend: getData: data:", type(data), repr(data))
        return data

